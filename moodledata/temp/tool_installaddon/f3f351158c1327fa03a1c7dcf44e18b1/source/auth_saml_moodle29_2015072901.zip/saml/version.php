<?php

$plugin->version = 2015072901;
$plugin->requires = 2012062500;
$plugin->release = 'auth/saml version of 29-07-2015';
$plugin->maturity = MATURITY_BETA;
